#!/bin/bash
# deploy-all.sh
# Despliega los 7 stacks de CloudFormation del Swift SQS Connector en orden.
#
# Uso:
#   chmod +x scripts/deploy-all.sh
#   ./scripts/deploy-all.sh \
#     sandbox \
#     us-east-1 \
#     core-swift-mt-inbound \
#     core-swift-mx-inbound \
#     core-swift-outbound \
#     mi-bucket-deploy
#
# Argumentos:
#   $1  environment     sandbox | test | prod
#   $2  region          us-east-1 | ...
#   $3  core-mt-queue   nombre de la cola MT del core
#   $4  core-mx-queue   nombre de la cola MX del core
#   $5  core-out-queue  nombre de la cola outbound del core
#   $6  deploy-bucket   bucket S3 con los ZIPs de las Lambdas
#   $7  core-fileact    nombre de la cola FileAct del core (opcional)

set -euo pipefail

ENV=${1:?'Argumento requerido: environment (sandbox|test|prod)'}
REGION=${2:?'Argumento requerido: region (ej. us-east-1)'}
CORE_MT=${3:?'Argumento requerido: core-mt-queue-name'}
CORE_MX=${4:?'Argumento requerido: core-mx-queue-name'}
CORE_OUT=${5:?'Argumento requerido: core-outbound-queue-name'}
BUCKET=${6:?'Argumento requerido: deploy-bucket-name'}
CORE_FILEACT=${7:-''}

PREFIX="swift-sqs-${ENV}"
CF_DIR="$(dirname "$0")/../cloudformation"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   Swift SQS Connector — Deploy CloudFormation        ║"
echo "╠══════════════════════════════════════════════════════╣"
echo "║  Environment : ${ENV}"
echo "║  Region      : ${REGION}"
echo "║  Core MT     : ${CORE_MT}"
echo "║  Core MX     : ${CORE_MX}"
echo "║  Core Out    : ${CORE_OUT}"
echo "║  FileAct     : ${CORE_FILEACT:-'(no configurado)'}"
echo "║  Bucket      : ${BUCKET}"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ── Helper: deploy un stack ───────────────────────────────────────────────
deploy_stack() {
  local stack_name=$1
  local template=$2
  shift 2
  local params=("$@")

  echo "▶ Deploying ${stack_name}..."

  local param_overrides=""
  for p in "${params[@]}"; do
    param_overrides="${param_overrides} ${p}"
  done

  aws cloudformation deploy \
    --stack-name "${stack_name}" \
    --template-file "${CF_DIR}/${template}" \
    --region "${REGION}" \
    --capabilities CAPABILITY_NAMED_IAM \
    --parameter-overrides \
      Environment="${ENV}" \
      ${param_overrides} \
    --tags \
      Project=swift-sqs-connector \
      Environment="${ENV}" \
    --no-fail-on-empty-changeset

  echo "  ✓ ${stack_name} deployed"
  echo ""
}

# ── Subir ZIPs al bucket S3 ───────────────────────────────────────────────
echo "[0/7] Subiendo Lambdas a S3..."
for zip in dist/*.zip; do
  filename=$(basename "${zip}")
  aws s3 cp "${zip}" "s3://${BUCKET}/${filename}" --region "${REGION}"
  echo "  ✓ ${filename}"
done
echo ""

# ── 1. KMS ────────────────────────────────────────────────────────────────
deploy_stack "${PREFIX}-kms" "01-kms.yaml"

# ── 2. DynamoDB ───────────────────────────────────────────────────────────
deploy_stack "${PREFIX}-dynamodb" "02-dynamodb.yaml"

# ── 3. SQS ────────────────────────────────────────────────────────────────
deploy_stack "${PREFIX}-sqs" "03-sqs.yaml" \
  "CoreMtInboundQueueName=${CORE_MT}" \
  "CoreMxInboundQueueName=${CORE_MX}" \
  "CoreOutboundQueueName=${CORE_OUT}" \
  "CoreFileActQueueName=${CORE_FILEACT}"

# ── 4. IAM ────────────────────────────────────────────────────────────────
deploy_stack "${PREFIX}-iam" "04-iam.yaml" \
  "CoreFileActQueueName=${CORE_FILEACT}"

# ── 5. Lambdas ────────────────────────────────────────────────────────────
deploy_stack "${PREFIX}-lambdas" "05-lambdas.yaml" \
  "DeployBucketName=${BUCKET}" \
  "CoreFileActQueueName=${CORE_FILEACT}"

# ── 6. EventBridge ────────────────────────────────────────────────────────
deploy_stack "${PREFIX}-eventbridge" "06-eventbridge.yaml"

# ── 7. Triggers ───────────────────────────────────────────────────────────
CORE_OUT_ARN=$(aws sqs get-queue-attributes \
  --queue-url "https://sqs.${REGION}.amazonaws.com/$(aws sts get-caller-identity --query Account --output text)/${CORE_OUT}" \
  --attribute-names QueueArn \
  --region "${REGION}" \
  --query 'Attributes.QueueArn' \
  --output text)

deploy_stack "${PREFIX}-triggers" "07-triggers.yaml" \
  "CoreOutboundQueueArn=${CORE_OUT_ARN}"

# ── Resumen de outputs ────────────────────────────────────────────────────
echo "╔══════════════════════════════════════════════════════╗"
echo "║   Deploy completado exitosamente ✓                   ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# Obtener outputs clave
TABLE=$(aws cloudformation describe-stacks \
  --stack-name "${PREFIX}-dynamodb" \
  --region "${REGION}" \
  --query 'Stacks[0].Outputs[?OutputKey==`TableName`].OutputValue' \
  --output text)

KMS_ID=$(aws cloudformation describe-stacks \
  --stack-name "${PREFIX}-kms" \
  --region "${REGION}" \
  --query 'Stacks[0].Outputs[?OutputKey==`KmsKeyId`].OutputValue' \
  --output text)

echo "Tabla DynamoDB : ${TABLE}"
echo "KMS Key ID     : ${KMS_ID}"
echo ""
echo "Siguiente paso — cargar credenciales Swift en DynamoDB:"
echo ""
echo "  DYNAMODB_TABLE_NAME=${TABLE} \\"
echo "  KMS_KEY_ID=${KMS_ID} \\"
echo "  SWIFT_ENV=${ENV} \\"
echo "  SWIFT_CONSUMER_KEY=<tu_consumer_key> \\"
echo "  SWIFT_CONSUMER_SECRET=<tu_consumer_secret> \\"
echo "  node scripts/setup-credentials.mjs"
echo ""
echo "Luego invocar el token-refresher para el primer token:"
echo ""
echo "  aws lambda invoke \\"
echo "    --function-name ${PREFIX}-token-refresher \\"
echo "    --region ${REGION} \\"
echo "    /dev/null"
