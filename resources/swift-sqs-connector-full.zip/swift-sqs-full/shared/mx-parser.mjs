/**
 * mx-parser.mjs
 * Parsea un mensaje MX completo (ISO 20022) con AppHdr (head.001) + Document.
 *
 * Input (texto plano del body SQS del core):
 *   <?xml version="1.0" encoding="UTF-8"?>
 *   <AppHdr xmlns="urn:iso:std:iso:20022:tech:xsd:head.001.001.02">
 *     <Fr><FIId><FinInstnId><BICFI>BANKPAXX</BICFI>...</FinInstnId></FIId></Fr>
 *     <To><FIId><FinInstnId><BICFI>BANAPAPAXXXX</BICFI>...</FinInstnId></FIId></To>
 *     <BizMsgIdr>MSG-001</BizMsgIdr>
 *     <MsgDefIdr>pacs.008.001.09</MsgDefIdr>
 *     <CreDt>2025-01-15T10:30:00Z</CreDt>
 *   </AppHdr>
 *   <Document xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.09">...</Document>
 *
 * Output (formato del spec Swift Messaging API v2.1.0):
 *   {
 *     sender_reference: "MSG-001",          // BizMsgIdr
 *     message_type:     "pacs.008.001.09",  // MsgDefIdr
 *     sender:           "BANKPAXXXXXX",     // BIC12 del Fr
 *     receiver:         "BANAPAPAXXXX",     // BIC12 del To
 *     payload:          "<base64>",          // XML completo en base64
 *     _meta: { bizMsgIdr, msgDefIdr, creDt, ... }
 *   }
 */

/**
 * Extrae el texto de un tag XML sin namespace.
 */
function extractTag(xml, tagName) {
  const patterns = [
    new RegExp(`<[^>]*:?${tagName}[^>]*>([^<]*)<\\/[^>]*:?${tagName}>`, 's'),
    new RegExp(`<${tagName}>([^<]*)<\\/${tagName}>`, 's'),
  ];
  for (const pattern of patterns) {
    const match = xml.match(pattern);
    if (match) return match[1].trim();
  }
  return null;
}

function extractAppHdr(xml) {
  const match = xml.match(/<(?:[^:>]+:)?AppHdr[\s\S]*?<\/(?:[^:>]+:)?AppHdr>/);
  return match ? match[0] : null;
}

function extractDocument(xml) {
  const match = xml.match(/<(?:[^:>]+:)?Document[\s\S]*?<\/(?:[^:>]+:)?Document>/);
  return match ? match[0] : null;
}

/**
 * Normaliza BIC a BIC12 (padEnd con X).
 */
function normalizeBic(bic) {
  if (!bic) return null;
  const clean = bic.trim().toUpperCase();
  if (clean.length === 8)  return clean + 'XXXX';
  if (clean.length === 11) return clean + 'X';
  return clean.padEnd(12, 'X').substring(0, 12);
}

function extractAppHdrNamespace(appHdrXml) {
  const match = appHdrXml?.match(/xmlns(?::[^=]+)?="([^"]+)"/);
  return match ? match[1] : null;
}

function extractSenderBic(appHdrXml) {
  const frBlock = appHdrXml?.match(/<(?:[^:>]+:)?Fr[\s\S]*?<\/(?:[^:>]+:)?Fr>/)
    ?? appHdrXml?.match(/<(?:[^:>]+:)?From[\s\S]*?<\/(?:[^:>]+:)?From>/);
  if (frBlock) return normalizeBic(extractTag(frBlock[0], 'BICFI'));
  return null;
}

function extractReceiverBic(appHdrXml) {
  const toBlock = appHdrXml?.match(/<(?:[^:>]+:)?To[\s\S]*?<\/(?:[^:>]+:)?To>/);
  if (toBlock) return normalizeBic(extractTag(toBlock[0], 'BICFI'));
  return null;
}

/**
 * Construye el payload XML limpio (AppHdr + Document sin wrapper).
 */
function buildPayloadXml(rawMX, appHdrXml, documentXml) {
  const trimmed = rawMX.trim();
  const hasWrapper = !trimmed.startsWith('<AppHdr') &&
                     !trimmed.startsWith('<?xml') &&
                     !trimmed.match(/^<(?:[^:>]+:)?AppHdr/);

  if (!hasWrapper) return rawMX;

  const xmlDecl = rawMX.match(/<\?xml[^?]*\?>/)?.[0] ?? '<?xml version="1.0" encoding="UTF-8"?>';
  return `${xmlDecl}\n${appHdrXml}\n${documentXml}`;
}

/**
 * Parser principal.
 * @param {string} rawMX - XML MX completo (AppHdr + Document)
 * @returns {SwiftInterActMessage}
 */
export function parseMXMessage(rawMX) {
  if (!rawMX || typeof rawMX !== 'string') {
    throw new Error('rawMX must be a non-empty string');
  }

  const appHdrXml = extractAppHdr(rawMX);
  if (!appHdrXml) throw new Error('AppHdr (head.001) not found in MX message');

  const documentXml = extractDocument(rawMX);
  if (!documentXml) throw new Error('Document element not found in MX message');

  const bizMsgIdr = extractTag(appHdrXml, 'BizMsgIdr');
  const msgDefIdr = extractTag(appHdrXml, 'MsgDefIdr');
  const creDt     = extractTag(appHdrXml, 'CreDt');

  if (!msgDefIdr) throw new Error('AppHdr/MsgDefIdr not found — cannot determine message type');

  const senderRef = bizMsgIdr;
  if (!senderRef) throw new Error('BizMsgIdr is empty — cannot determine sender_reference');
  if (senderRef.length > 70) throw new Error(`sender_reference exceeds 70 chars: ${senderRef}`);

  const senderBic   = extractSenderBic(appHdrXml);
  const receiverBic = extractReceiverBic(appHdrXml);
  if (!receiverBic) throw new Error('Could not extract receiver BIC from AppHdr/To');

  const payloadXml = buildPayloadXml(rawMX, appHdrXml, documentXml);
  const payloadB64 = Buffer.from(payloadXml, 'utf8').toString('base64');

  return {
    sender_reference: senderRef,
    message_type:     msgDefIdr,
    sender:           senderBic,
    receiver:         receiverBic,
    payload:          payloadB64,
    _meta: {
      bizMsgIdr,
      msgDefIdr,
      creDt,
      senderBic,
      receiverBic,
      appHdrNamespace: extractAppHdrNamespace(appHdrXml),
    },
  };
}

/**
 * Detecta si un mensaje raw es MT o MX.
 */
export function detectMessageFormat(raw) {
  if (!raw) throw new Error('Empty message');
  const trimmed = raw.trim();

  if (trimmed.startsWith('{1:') || trimmed.startsWith('{2:') || trimmed.startsWith('{')) return 'MT';
  if (trimmed.startsWith('<?xml') || trimmed.includes('urn:iso:std:iso:20022')) return 'MX';

  throw new Error('Cannot detect message format — does not look like MT or MX');
}
