/**
 * swift-store.mjs
 * Reemplaza Secrets Manager. Usa DynamoDB + KMS para guardar
 * credenciales Swift y el Bearer token con cifrado de campo.
 *
 * Tabla DynamoDB: swift-sqs-{env}-store
 * Partition Key:  pk (String)
 *
 * Ítem "credentials" (escrito manualmente en el deploy):
 * {
 *   pk:              "credentials",
 *   consumer_key:    "...",           ← en claro (no sensible)
 *   consumer_secret: "<encrypted>",   ← cifrado con KMS
 *   private_key_pem: "<encrypted>",   ← cifrado con KMS
 *   certificate_pem: "<encrypted>",   ← cifrado con KMS
 *   updated_at:      "ISO timestamp"
 * }
 *
 * Ítem "token" (escrito por token-refresher cada 50 min):
 * {
 *   pk:           "token",
 *   access_token: "<encrypted>",  ← cifrado con KMS
 *   expires_in:   1799,           ← número, en claro
 *   obtained_at:  "ISO timestamp" ← en claro
 * }
 *
 * Cifrado: KMS Encrypt / Decrypt con clave gestionada por AWS (CMK).
 * Los valores cifrados se guardan como Binary (Buffer) en DynamoDB.
 *
 * Caché en memoria: el token se cachea 45 min para no llamar a
 * DynamoDB en cada invocación Lambda (warm container).
 *
 * Environment variables requeridas:
 *   DYNAMODB_TABLE_NAME   Nombre de la tabla DynamoDB
 *   KMS_KEY_ID            ID o ARN de la clave KMS
 *   AWS_REGION            Región AWS (inyectada por Lambda automáticamente)
 */

import {
  DynamoDBClient,
  GetItemCommand,
  PutItemCommand,
} from '@aws-sdk/client-dynamodb';
import { marshall, unmarshall } from '@aws-sdk/util-dynamodb';
import {
  KMSClient,
  EncryptCommand,
  DecryptCommand,
} from '@aws-sdk/client-kms';

const dynamo = new DynamoDBClient({});
const kms    = new KMSClient({});

const TABLE = process.env.DYNAMODB_TABLE_NAME;
const KEY   = process.env.KMS_KEY_ID;

// ── Caché en memoria ──────────────────────────────────────────────────────
let _tokenCache       = null;
let _tokenCachedAt    = 0;
let _credsCache       = null;
const TOKEN_TTL_MS    = 45 * 60 * 1000; // 45 min
const CREDS_TTL_MS    = 60 * 60 * 1000; // 60 min (estáticas, cambian poco)

// ── Helpers KMS ───────────────────────────────────────────────────────────

/**
 * Cifra un string con KMS. Devuelve el ciphertext como Buffer.
 */
async function kmsEncrypt(plaintext) {
  const { CiphertextBlob } = await kms.send(new EncryptCommand({
    KeyId:     KEY,
    Plaintext: Buffer.from(plaintext, 'utf8'),
  }));
  return Buffer.from(CiphertextBlob);
}

/**
 * Descifra un valor cifrado con KMS.
 * Acepta Buffer, Uint8Array o base64 string.
 */
async function kmsDecrypt(ciphertext) {
  const blob = Buffer.isBuffer(ciphertext)
    ? ciphertext
    : Buffer.from(ciphertext);

  const { Plaintext } = await kms.send(new DecryptCommand({
    CiphertextBlob: blob,
    KeyId:          KEY,
  }));
  return Buffer.from(Plaintext).toString('utf8');
}

// ── DynamoDB helpers ──────────────────────────────────────────────────────

async function dbGet(pk) {
  const { Item } = await dynamo.send(new GetItemCommand({
    TableName: TABLE,
    Key:       marshall({ pk }),
  }));
  return Item ? unmarshall(Item) : null;
}

async function dbPut(item) {
  await dynamo.send(new PutItemCommand({
    TableName: TABLE,
    Item:      marshall(item, { convertClassInstanceToMap: true }),
  }));
}

// ── API pública ───────────────────────────────────────────────────────────

/**
 * Lee y descifra las credenciales Swift desde DynamoDB.
 * Usa caché en memoria para contenedores Lambda calientes.
 *
 * @returns {{ consumer_key, consumer_secret, private_key_pem, certificate_pem }}
 */
export async function getCredentials() {
  const now = Date.now();
  if (_credsCache && (now - _tokenCachedAt) < CREDS_TTL_MS) {
    return _credsCache;
  }

  const item = await dbGet('credentials');
  if (!item) throw new Error('Credentials not found in DynamoDB. Run the setup script first.');

  // Descifrar campos sensibles en paralelo
  const [consumer_secret, private_key_pem, certificate_pem] = await Promise.all([
    kmsDecrypt(item.consumer_secret),
    kmsDecrypt(item.private_key_pem),
    kmsDecrypt(item.certificate_pem),
  ]);

  _credsCache = {
    consumer_key:    item.consumer_key,  // en claro
    consumer_secret,
    private_key_pem,
    certificate_pem,
  };

  return _credsCache;
}

/**
 * Lee y descifra el Bearer token desde DynamoDB.
 * Usa caché en memoria de 45 min.
 *
 * @returns {{ access_token, expires_in, obtained_at }}
 */
export async function getToken() {
  const now = Date.now();
  if (_tokenCache && (now - _tokenCachedAt) < TOKEN_TTL_MS) {
    return _tokenCache;
  }

  const item = await dbGet('token');
  if (!item || !item.access_token) {
    throw new Error('Token not found in DynamoDB. Invoke token-refresher first.');
  }

  const access_token = await kmsDecrypt(item.access_token);

  _tokenCache = {
    access_token,
    expires_in:  item.expires_in,
    obtained_at: item.obtained_at,
  };
  _tokenCachedAt = now;

  return _tokenCache;
}

/**
 * Cifra y guarda el Bearer token en DynamoDB.
 * Llamado por token-refresher después de obtener el token de Swift.
 *
 * @param {{ access_token, expires_in }} tokenData
 */
export async function saveToken(tokenData) {
  const encryptedToken = await kmsEncrypt(tokenData.access_token);

  await dbPut({
    pk:           'token',
    access_token: encryptedToken,          // Binary cifrado
    expires_in:   parseInt(tokenData.expires_in, 10),
    obtained_at:  new Date().toISOString(),
  });

  // Invalidar caché para forzar re-lectura
  _tokenCache    = null;
  _tokenCachedAt = 0;

  console.log('swift-store: token saved to DynamoDB');
}

/**
 * Cifra y guarda las credenciales Swift en DynamoDB.
 * Se llama UNA VEZ durante el setup inicial o cuando rotan las credenciales.
 *
 * @param {{ consumer_key, consumer_secret, private_key_pem, certificate_pem }} creds
 */
export async function saveCredentials(creds) {
  const [
    enc_consumer_secret,
    enc_private_key_pem,
    enc_certificate_pem,
  ] = await Promise.all([
    kmsEncrypt(creds.consumer_secret),
    kmsEncrypt(creds.private_key_pem),
    kmsEncrypt(creds.certificate_pem),
  ]);

  await dbPut({
    pk:              'credentials',
    consumer_key:    creds.consumer_key,     // en claro — no sensible
    consumer_secret: enc_consumer_secret,
    private_key_pem: enc_private_key_pem,
    certificate_pem: enc_certificate_pem,
    updated_at:      new Date().toISOString(),
  });

  // Invalidar caché
  _credsCache = null;

  console.log('swift-store: credentials saved to DynamoDB');
}
