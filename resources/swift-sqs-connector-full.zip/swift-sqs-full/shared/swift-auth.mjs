/**
 * swift-auth.mjs
 * Construye el JWT RS256 para autenticación OAuth2 con Swift
 * y obtiene el Bearer token del endpoint OAuth2.
 *
 * Usado por: token-refresher
 *
 * Flujo validado contra sandbox.swift.com:
 *   1. En sandbox: descarga llaves del endpoint sandbox-selfsigned-dummy-secret
 *   2. Construye JWT con crypto nativo Node.js (NO jose)
 *   3. POST con Basic Auth en header + JWT assertion en body
 *   4. Scope: swift.alliancecloud.api (sin /access_to_service)
 *   5. exp = now + 15 seg (no 900)
 */

import crypto from 'crypto';

const CONFIG = {
  sandbox: {
    baseUrl:  'https://sandbox.swift.com',
    tokenUri: '/oauth2/v1/token',
    scope:    'swift.alliancecloud.api',
  },
  test: {
    baseUrl:  'https://api-test.swiftnet.sipn.swift.com',
    tokenUri: '/oauth2/v1/token',
    scope:    'swift.alliancecloud.api',
  },
  prod: {
    baseUrl:  'https://api.swiftnet.sipn.swift.com',
    tokenUri: '/oauth2/v1/token',
    scope:    'swift.alliancecloud.api',
  },
};

const ENV = process.env.SWIFT_ENV || 'sandbox';
const { baseUrl, tokenUri, scope } = CONFIG[ENV];

/**
 * Encode base64 a base64url.
 */
function base64UrlEncode(str) {
  return str.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

/**
 * Procesa el certificado PEM al formato x5c para el JWT header.
 * Remueve headers, footers y saltos de línea.
 */
export function getX5c(certificatePem) {
  return certificatePem
    .replace('-----BEGIN CERTIFICATE-----', '')
    .replace('-----END CERTIFICATE-----', '')
    .replace(/\n/g, '');
}

/**
 * Extrae el Subject DN del certificado.
 * En sandbox siempre es: CN=demo-swift-sandbox-consumer, O=Demo, L=London, S=London, C=GB
 */
export function getSubjectDn(certificatePem) {
  try {
    const cert = new crypto.X509Certificate(certificatePem);
    return cert.subject.split('\n').filter(Boolean).join(', ');
  } catch {
    return 'CN=demo-swift-sandbox-consumer, O=Demo, L=London, S=London, C=GB';
  }
}

/**
 * Construye y firma el JWT RS256 para el JWT-Bearer grant.
 * Basado en el sample code oficial de Swift (bearer-token.ts).
 *
 * @param {{ privateKeyPem, certificatePem, consumerKey }} opts
 * @returns {string} JWT firmado
 */
export function buildJwt({ privateKeyPem, certificatePem, consumerKey }) {
  const x5c     = getX5c(certificatePem);
  const subject = getSubjectDn(certificatePem);
  const aud     = `${baseUrl}${tokenUri}`.replace('https://', '');
  const now     = Math.floor(Date.now() / 1000);

  const header = { alg: 'RS256', typ: 'JWT', x5c: [x5c] };
  const payload = {
    iss: consumerKey,
    sub: subject,
    aud,
    exp: now + 15,   // 15 seg — igual que el sample oficial de Swift
    iat: now,
    nbf: now,
    jti: Math.random().toString(36).substring(2, 15) +
         Math.random().toString(36).substring(2, 15),
  };

  const h = base64UrlEncode(Buffer.from(JSON.stringify(header)).toString('base64'));
  const p = base64UrlEncode(Buffer.from(JSON.stringify(payload)).toString('base64'));

  const privateKey = crypto.createPrivateKey({ key: privateKeyPem });
  const signature  = crypto.createSign('RSA-SHA256').update(`${h}.${p}`).sign(privateKey);

  return `${h}.${p}.${base64UrlEncode(signature.toString('base64'))}`;
}

/**
 * En sandbox: descarga las llaves PKI del endpoint público de Swift.
 * En test/prod: usa las llaves del ítem "credentials" de DynamoDB.
 *
 * @param {{ private_key_pem, certificate_pem }} creds
 * @returns {{ privateKeyPem, certificatePem }}
 */
export async function resolveKeys(creds) {
  if (ENV === 'sandbox') {
    const SERVER = 'https://sandbox.swift.com';
    const [pkRes, certRes] = await Promise.all([
      fetch(`${SERVER}/sandbox-selfsigned-dummy-secret/privatekey2`),
      fetch(`${SERVER}/sandbox-selfsigned-dummy-secret/certificate2`),
    ]);
    return {
      privateKeyPem:  `-----BEGIN PRIVATE KEY-----\n${(await pkRes.text()).trim()}\n-----END PRIVATE KEY-----`,
      certificatePem: `-----BEGIN CERTIFICATE-----\n${(await certRes.text()).trim()}\n-----END CERTIFICATE-----`,
    };
  }
  return {
    privateKeyPem:  creds.private_key_pem,
    certificatePem: creds.certificate_pem,
  };
}

/**
 * Obtiene el Bearer token de Swift OAuth2.
 * Autenticación: JWT-Bearer grant + Basic Auth en header.
 *
 * @param {{ consumer_key, consumer_secret, private_key_pem, certificate_pem }} creds
 * @returns {{ access_token, expires_in, refresh_token, ... }}
 */
export async function fetchSwiftToken(creds) {
  const { privateKeyPem, certificatePem } = await resolveKeys(creds);

  const assertion = buildJwt({
    privateKeyPem,
    certificatePem,
    consumerKey: creds.consumer_key,
  });

  const basicAuth = Buffer.from(
    `${creds.consumer_key}:${creds.consumer_secret}`
  ).toString('base64');

  const response = await fetch(`${baseUrl}${tokenUri}`, {
    method: 'POST',
    headers: {
      'Content-Type':  'application/x-www-form-urlencoded',
      'Accept':        'application/json',
      'Authorization': `Basic ${basicAuth}`,
    },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion,
      scope,
    }).toString(),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(`Swift OAuth failed ${response.status}: ${JSON.stringify(err)}`);
  }

  return response.json();
}
