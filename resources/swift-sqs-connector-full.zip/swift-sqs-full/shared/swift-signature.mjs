/**
 * swift-signature.mjs
 * Construye el header X-SWIFT-Signature requerido para envío de mensajes.
 *
 * Basado en signature.ts del sample code oficial de Swift.
 *
 * El X-SWIFT-Signature es un JWS RS256 que incluye:
 *   - sub:    Subject DN del certificado institucional
 *   - aud:    URL del endpoint sin https://
 *   - exp:    now + 15 seg
 *   - iat:    now
 *   - nbf:    now
 *   - jti:    nonce aleatorio
 *   - digest: SHA256(base64(bodyString)) — vincula la firma al payload
 */

import crypto from 'crypto';

/**
 * Encode base64 a base64url.
 */
function base64UrlEncode(str) {
  return str.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

/**
 * Procesa certificado PEM al formato x5c.
 */
function getX5c(certificatePem) {
  return certificatePem
    .replace('-----BEGIN CERTIFICATE-----', '')
    .replace('-----END CERTIFICATE-----', '')
    .replace(/\n/g, '');
}

/**
 * Extrae el Subject DN del certificado.
 */
function getSubjectDn(certificatePem) {
  try {
    const cert = new crypto.X509Certificate(certificatePem);
    return cert.subject.split('\n').filter(Boolean).join(', ');
  } catch {
    return 'CN=demo-swift-sandbox-consumer, O=Demo, L=London, S=London, C=GB';
  }
}

/**
 * Calcula el digest SHA256 del body para el X-SWIFT-Signature.
 *   1. bodyString → base64
 *   2. SHA256(base64) → digest en base64
 */
function calculateDigest(bodyString) {
  const dataBase64 = Buffer.from(bodyString).toString('base64');
  return crypto.createHash('sha256').update(dataBase64).digest('base64');
}

/**
 * Construye el header X-SWIFT-Signature (JWS RS256).
 *
 * @param {string} url          - URL completa del endpoint
 * @param {string} bodyString   - Body JSON serializado (JSON.stringify)
 * @param {{ privateKeyPem, certificatePem }} credentials
 * @returns {string} JWS firmado para usar como X-SWIFT-Signature
 */
export function buildSwiftSignature(url, bodyString, { privateKeyPem, certificatePem }) {
  const x5c     = getX5c(certificatePem);
  const subject = getSubjectDn(certificatePem);
  const now     = Math.floor(Date.now() / 1000);

  const header = { alg: 'RS256', typ: 'JWT', x5c: [x5c] };
  const payload = {
    sub:    subject,
    aud:    url.replace('https://', ''),
    exp:    now + 15,
    iat:    now,
    nbf:    now,
    jti:    Math.random().toString(36).substring(2, 15) +
            Math.random().toString(36).substring(2, 15),
    digest: calculateDigest(bodyString),
  };

  const h = base64UrlEncode(Buffer.from(JSON.stringify(header)).toString('base64'));
  const p = base64UrlEncode(Buffer.from(JSON.stringify(payload)).toString('base64'));

  const privateKey = crypto.createPrivateKey({ key: privateKeyPem });
  const signature  = crypto.createSign('RSA-SHA256').update(`${h}.${p}`).sign(privateKey);

  return `${h}.${p}.${base64UrlEncode(signature.toString('base64'))}`;
}
