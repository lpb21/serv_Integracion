/**
 * swift-client-outbound.mjs
 * Cliente HTTP para envío de mensajes a Swift — operaciones outbound.
 *
 * Cubre:
 *   POST /fin/messages              → FIN individual (MT)
 *   POST /fin/messages/batch        → FIN batch (hasta 500)
 *   POST /interact/messages         → InterAct individual (MX)
 *   POST /interact/messages/batch   → InterAct batch (hasta 50)
 *   POST /fileact/messages          → FileAct
 *
 * X-SWIFT-Signature: requerido por Alliance Cloud para todos los envíos.
 * Implementado en swift-signature.mjs.
 */

import { buildSwiftSignature } from './swift-signature.mjs';

const CONFIG = {
  sandbox: 'https://sandbox.swift.com/alliancecloud/v2',
  test:    'https://api-test.swiftnet.sipn.swift.com/alliancecloud/v2',
  prod:    'https://api.swiftnet.sipn.swift.com/alliancecloud/v2',
};

const ENV      = process.env.SWIFT_ENV || 'sandbox';
const BASE_URL = CONFIG[ENV];

const FIN_BATCH_MAX      = 500;
const INTERACT_BATCH_MAX = 50;

/**
 * HTTP helper para llamadas outbound con X-SWIFT-Signature.
 */
async function swiftPost(token, path, body, { credentials, maxRetries = 3 } = {}) {
  const url        = `${BASE_URL}${path}`;
  const bodyString = JSON.stringify(body);

  // Construir X-SWIFT-Signature si se proveen credenciales PKI
  const signature = credentials
    ? buildSwiftSignature(url, bodyString, credentials)
    : '';

  let attempt = 0;

  while (attempt <= maxRetries) {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization':    `Bearer ${token}`,
        'Content-Type':     'application/json',
        'Accept':           'application/json',
        'X-SWIFT-Signature': signature,
      },
      body: bodyString,
    });

    if (response.status === 201 || response.status === 202) {
      const data = await response.json().catch(() => ({}));
      return { data, status: response.status };
    }

    const errorBody   = await response.json().catch(() => ({}));
    const isTransient = response.status === 429 ||
      (response.status >= 500 && errorBody?.severity === 'Transient');

    if (isTransient && attempt < maxRetries) {
      const delay = Math.pow(2, attempt) * 500;
      console.warn(`Swift upload transient error (attempt ${attempt + 1}), retry in ${delay}ms`);
      await new Promise(r => setTimeout(r, delay));
      attempt++;
      continue;
    }

    const err      = new Error(`Swift upload error ${response.status}: ${errorBody?.text || 'unknown'}`);
    err.statusCode = response.status;
    err.swiftCode  = errorBody?.code;
    err.severity   = errorBody?.severity;
    throw err;
  }
}

/**
 * Detecta si un mensaje es FIN o InterAct por el message_type.
 *   FIN:     fin.103, fin.202, fin.202.COV, fin.900, fin.910, apc.*
 *   InterAct: pacs.008, pacs.009, camt.*, pain.* etc.
 */
export function detectService(messageType) {
  if (!messageType) throw new Error('message_type is required');
  if (messageType.startsWith('fin.') || messageType.startsWith('apc.')) return 'fin';
  return 'interAct';
}

/**
 * POST /fin/messages — FIN individual.
 * @param {string} token
 * @param {object} message - { sender_reference, message_type, receiver, payload, network_info? }
 * @param {object} credentials - { privateKeyPem, certificatePem } para X-SWIFT-Signature
 */
export async function sendFinMessage(token, message, credentials) {
  const { data } = await swiftPost(token, '/fin/messages', message, { credentials });
  return data;
}

/**
 * POST /fin/messages/batch — hasta 500 mensajes FIN.
 * Divide automáticamente en sub-lotes si supera el límite.
 */
export async function sendFinMessageBatch(token, messages, credentials) {
  const allResults = [];
  for (let i = 0; i < messages.length; i += FIN_BATCH_MAX) {
    const chunk    = messages.slice(i, i + FIN_BATCH_MAX);
    const { data } = await swiftPost(token, '/fin/messages/batch', { messages: chunk }, { credentials });
    allResults.push(...(data?.results ?? []));
  }
  return allResults;
}

/**
 * POST /interact/messages — InterAct individual.
 */
export async function sendInterActMessage(token, message, credentials) {
  const { data } = await swiftPost(token, '/interact/messages', message, { credentials });
  return data;
}

/**
 * POST /interact/messages/batch — hasta 50 mensajes InterAct.
 */
export async function sendInterActMessageBatch(token, messages, credentials) {
  const allResults = [];
  for (let i = 0; i < messages.length; i += INTERACT_BATCH_MAX) {
    const chunk    = messages.slice(i, i + INTERACT_BATCH_MAX);
    const { data } = await swiftPost(token, '/interact/messages/batch', { messages: chunk }, { credentials });
    allResults.push(...(data?.results ?? []));
  }
  return allResults;
}

/**
 * POST /fileact/messages — FileAct.
 */
export async function sendFileActMessage(token, fileMessage, credentials) {
  const { data } = await swiftPost(token, '/fileact/messages', fileMessage, { credentials });
  return data;
}

/**
 * Router principal — detecta servicio y envía.
 * @param {string} token
 * @param {object|object[]} messages
 * @param {object} credentials - { privateKeyPem, certificatePem }
 */
export async function sendMessages(token, messages, credentials) {
  const isArray = Array.isArray(messages);
  const list    = isArray ? messages : [messages];

  if (list.length === 0) throw new Error('No messages to send');

  const service = detectService(list[0].message_type);
  const allSameService = list.every(m => detectService(m.message_type) === service);
  if (!allSameService) {
    throw new Error('All messages in a batch must be the same service (fin or interAct)');
  }

  let result;
  if (service === 'fin') {
    result = list.length === 1
      ? await sendFinMessage(token, list[0], credentials)
      : await sendFinMessageBatch(token, list, credentials);
  } else {
    result = list.length === 1
      ? await sendInterActMessage(token, list[0], credentials)
      : await sendInterActMessageBatch(token, list, credentials);
  }

  return isArray ? result : result;
}
