/**
 * mt-parser.mjs
 * Parsea un mensaje MT completo con todos los bloques SWIFT.
 *
 * Input (texto plano del body SQS del core):
 *   {1:F01BANKPAXXX0000000000}{2:I103BANAPAPAXXXXN}{3:{108:TXN-001}{121:uuid}}{4:\r\n:20:...\r\n-}{5:{CHK:...}}
 *
 * Output (formato del spec Swift Messaging API v2.1.0):
 *   {
 *     sender_reference: "TXN-001",       // del campo {108:} bloque 3
 *     message_type:     "fin.103",        // "fin." + tipo bloque 2 + variante {119:}
 *     sender:           "BANKPAXXX000",   // BIC12 bloque 1
 *     receiver:         "BANAPAPAXXXX",   // BIC12 bloque 2
 *     payload:          "<base64>",       // solo bloque 4 en base64
 *     network_info:     { network_priority: "Normal" },
 *     _meta: { uetr, validationFlag, rawBlocks, ... }
 *   }
 */

/**
 * Extrae los bloques del mensaje MT completo.
 * @returns {Map<string, string>} bloques indexados por número
 */
export function parseBlocks(rawMT) {
  const blocks = new Map();
  const blockRegex = /\{(\d):([\s\S]*?)\}(?=\{\d:|$)/g;
  let match;

  while ((match = blockRegex.exec(rawMT)) !== null) {
    blocks.set(match[1], match[2]);
  }

  // Fallback para bloque 4 (puede contener llaves anidadas)
  if (!blocks.has('4')) {
    const b4match = rawMT.match(/\{4:([\s\S]*?)\r?\n-\}/);
    if (b4match) blocks.set('4', b4match[1]);
  }

  return blocks;
}

/**
 * Parsea el bloque 1 (Basic Header).
 * Formato: F01BANKPAXXX0000000000
 */
export function parseBlock1(b1) {
  if (!b1 || b1.length < 10) return null;
  return {
    applicationId: b1[0],
    serviceId:     b1.substring(1, 3),
    senderBic12:   b1.substring(3, 15).padEnd(12, 'X'),
  };
}

/**
 * Parsea el bloque 2 (Application Header).
 * Formato outgoing: I103BANAPAPAXXXXN
 *   I + msgtype(3) + receiver(12) + priority(1)
 */
export function parseBlock2(b2) {
  if (!b2) return null;
  const direction = b2[0];

  if (direction === 'I') {
    return {
      direction:       'Outgoing',
      messageTypeCode: b2.substring(1, 4),
      receiverBic12:   b2.substring(4, 16).padEnd(12, 'X'),
      networkPriority: mapPriority(b2[16] ?? 'N'),
    };
  }

  if (direction === 'O') {
    return {
      direction:       'Incoming',
      messageTypeCode: b2.substring(1, 4),
    };
  }

  return null;
}

/**
 * Parsea el bloque 3 (User Header) — sub-bloques {NNN:valor}.
 * Campos relevantes:
 *   {108:} MUR — Message User Reference (sender_reference)
 *   {119:} Validation flag — STP, REMIT, COV → variante del message_type
 *   {121:} UETR — UUID para tracking ISO 20022
 */
export function parseBlock3(b3) {
  if (!b3) return {};
  const fields = {};
  const fieldRegex = /\{(\d{3}):([^}]*)\}/g;
  let match;

  while ((match = fieldRegex.exec(b3)) !== null) {
    fields[match[1]] = match[2].trim();
  }

  return {
    mur:             fields['108'] ?? null,
    validationFlag:  fields['119'] ?? null,
    uetr:            fields['121'] ?? null,
    raw:             fields,
  };
}

/**
 * Extrae y limpia el contenido del bloque 4 (Text Block).
 * El spec de Swift espera solo el bloque 4 en base64 — no el mensaje completo.
 */
export function extractBlock4(b4) {
  if (!b4) throw new Error('Block 4 (text block) is missing from MT message');
  let text = b4;
  if (text.startsWith('\r\n')) text = text.substring(2);
  if (text.startsWith('\n'))   text = text.substring(1);
  return text;
}

/**
 * Construye el message_type en el formato del spec:
 *   "fin.103", "fin.202", "fin.202.COV", "fin.103.REMIT", "fin.900"
 */
export function buildMessageType(typeCode, validationFlag) {
  const base = `fin.${typeCode}`;
  if (!validationFlag) return base;
  const variantFlags = ['COV', 'REMIT', 'STP'];
  if (variantFlags.includes(validationFlag.toUpperCase())) {
    return `${base}.${validationFlag.toUpperCase()}`;
  }
  return base;
}

function mapPriority(char) {
  return { 'N': 'Normal', 'U': 'Urgent', 'S': 'System' }[char?.toUpperCase()] ?? 'Normal';
}

/**
 * Parser principal.
 * @param {string} rawMT - Mensaje MT completo con bloques {1:...}{2:...}{3:...}{4:...}{5:...}
 * @returns {SwiftFinMessage}
 */
export function parseMTMessage(rawMT) {
  if (!rawMT || typeof rawMT !== 'string') {
    throw new Error('rawMT must be a non-empty string');
  }

  const blocks = parseBlocks(rawMT);

  if (!blocks.has('2')) throw new Error('Block 2 (Application Header) is missing');
  if (!blocks.has('4')) throw new Error('Block 4 (Text Block) is missing');

  const b1 = parseBlock1(blocks.get('1') ?? '');
  const b2 = parseBlock2(blocks.get('2'));
  const b3 = parseBlock3(blocks.get('3') ?? '');

  if (!b2) throw new Error('Could not parse Block 2');
  if (b2.direction !== 'Outgoing') {
    throw new Error(`MT message direction is '${b2.direction}' — only Outgoing messages should be sent`);
  }

  const senderRef = b3.mur ?? `AUTO-${Date.now()}`;
  if (senderRef.length > 70) throw new Error(`sender_reference exceeds 70 chars: ${senderRef}`);

  const block4Text = extractBlock4(blocks.get('4'));
  const payloadB64 = Buffer.from(block4Text, 'utf8').toString('base64');

  return {
    sender_reference: senderRef,
    message_type:     buildMessageType(b2.messageTypeCode, b3.validationFlag),
    sender:           b1?.senderBic12 ?? null,
    receiver:         b2.receiverBic12,
    payload:          payloadB64,
    network_info: {
      network_priority: b2.networkPriority,
    },
    _meta: {
      uetr:            b3.uetr,
      validationFlag:  b3.validationFlag,
      messageTypeCode: b2.messageTypeCode,
      rawBlocks:       Object.fromEntries(blocks),
    },
  };
}
