/**
 * queue-router.mjs
 * Enruta distribuciones Swift a las colas SQS del core bancario.
 *
 * Colas del core (ya existen, el conector NO las crea):
 *   SQS_CORE_MT_INBOUND_URL  → mensajes FIN (fin)
 *   SQS_CORE_MX_INBOUND_URL  → mensajes MX (interAct)
 *   SQS_CORE_FILEACT_URL     → FileAct (opcional — pendiente)
 *
 * El body publicado en las colas del core es el payload Swift
 * decodificado de base64 a TEXTO PLANO — sin wrapper JSON.
 * El core lo consume sin necesidad de cambios.
 */

const SERVICE_TO_ENV = {
  fin:      'SQS_CORE_MT_INBOUND_URL',
  interAct: 'SQS_CORE_MX_INBOUND_URL',
  fileAct:  'SQS_CORE_FILEACT_URL',
};

/**
 * Resuelve la URL de la cola del core para un servicio Swift.
 */
export function resolveQueueUrl(service) {
  const envVar = SERVICE_TO_ENV[service];
  if (!envVar) throw new Error(`Unknown Swift service: ${service}`);

  const url = process.env[envVar];

  if (!url) {
    if (service === 'fileAct') {
      throw new Error(
        'FileAct queue not configured (SQS_CORE_FILEACT_URL is empty). ' +
        'Set this env var when the core defines the FileAct queue.'
      );
    }
    throw new Error(`Queue URL not configured for service '${service}' (env: ${envVar})`);
  }

  return url;
}

/**
 * Construye el mensaje SQS para publicar en la cola del core.
 *
 * Body: payload Swift decodificado de base64 a texto plano.
 *   FIN:      texto MT (bloque 4)
 *   InterAct: XML MX completo (AppHdr + Document)
 *
 * MessageAttributes: metadata para filtrado sin parsear el body.
 */
export function buildSqsMessage(downloaded) {
  const { payload, integrity, distributionId, service, type } = downloaded;

  // Decodificar payload de base64 a texto plano
  let rawPayload;
  try {
    const payloadData = payload?.payload ?? payload;
    rawPayload = typeof payloadData === 'string'
      ? Buffer.from(payloadData, 'base64').toString('utf8')
      : JSON.stringify(payloadData);
  } catch {
    rawPayload = typeof payload === 'string' ? payload : JSON.stringify(payload);
  }

  const messageAttributes = {
    distributionId: {
      DataType:    'Number',
      StringValue: String(distributionId),
    },
    service: {
      DataType:    'String',
      StringValue: service,
    },
    distributionType: {
      DataType:    'String',
      StringValue: type,
    },
    swiftEnv: {
      DataType:    'String',
      StringValue: process.env.SWIFT_ENV ?? 'sandbox',
    },
    ...(integrity && {
      integrityToken: {
        DataType:    'String',
        StringValue: integrity,
      },
    }),
  };

  return { messageBody: rawPayload, messageAttributes };
}
