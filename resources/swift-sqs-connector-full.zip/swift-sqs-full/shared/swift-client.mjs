/**
 * swift-client.mjs
 * Cliente HTTP para la Swift Messaging API v2.1.0 — operaciones inbound.
 *
 * Cubre:
 *   GET  /distributions          → lista distribuciones pendientes (paginado)
 *   GET  /distributions/{id}     → distribución individual
 *   POST /distributions/{id}/acks  → ACK
 *   POST /distributions/{id}/naks  → NAK
 *   PATCH /distributions           → batch ACK/NAK
 *   Download por link rel:download → descarga payload de cualquier servicio
 *
 * URL base:
 *   sandbox: https://sandbox.swift.com/alliancecloud/v2
 *   prod:    https://api.swiftnet.sipn.swift.com/alliancecloud/v2
 */

const CONFIG = {
  sandbox: 'https://sandbox.swift.com/alliancecloud/v2',
  test:    'https://api-test.swiftnet.sipn.swift.com/alliancecloud/v2',
  prod:    'https://api.swiftnet.sipn.swift.com/alliancecloud/v2',
};

const ENV      = process.env.SWIFT_ENV || 'sandbox';
const BASE_URL = CONFIG[ENV];

/**
 * HTTP helper con retry + exponential backoff.
 * Reintenta automáticamente en errores transientes (429, 5xx Transient).
 */
async function swiftFetch(token, path, { method = 'GET', body, maxRetries = 3 } = {}) {
  const url = path.startsWith('http') ? path : `${BASE_URL}${path}`;
  let attempt = 0;

  while (attempt <= maxRetries) {
    const response = await fetch(url, {
      method,
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type':  'application/json',
        'Accept':        'application/json',
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    if (response.ok) {
      const integrity = response.headers.get('X-SWIFT-Integrity');
      const data      = await response.json();
      return { data, integrity };
    }

    const errorBody   = await response.json().catch(() => ({}));
    const isTransient = response.status === 429 ||
      (response.status >= 500 && errorBody?.severity === 'Transient');

    if (isTransient && attempt < maxRetries) {
      const delay = Math.pow(2, attempt) * 500;
      console.warn(`Swift API transient error (attempt ${attempt + 1}), retry in ${delay}ms`);
      await new Promise(r => setTimeout(r, delay));
      attempt++;
      continue;
    }

    const err      = new Error(`Swift API error ${response.status}: ${errorBody?.text || 'unknown'}`);
    err.statusCode = response.status;
    err.swiftCode  = errorBody?.code;
    err.severity   = errorBody?.severity;
    throw err;
  }
}

/**
 * GET /distributions
 * Pagina automáticamente usando el link rel:next hasta obtener todas.
 *
 * @param {string} token - Bearer token
 * @returns {Promise<Distribution[]>}
 */
export async function listDistributions(token) {
  const PAGE_SIZE = 100;
  let offset = 0;
  const all  = [];

  while (true) {
    const { data } = await swiftFetch(token, `/distributions?limit=${PAGE_SIZE}&offset=${offset}`);
    const distributions = data?.distributions ?? [];
    all.push(...distributions);

    const hasNext = data?.links?.some(l => l.rel === 'next');
    if (!hasNext || distributions.length < PAGE_SIZE) break;
    offset += PAGE_SIZE;
  }

  return all;
}

/**
 * Descarga el payload de una distribución.
 * Usa el link rel:download que viene en la distribución — más robusto
 * que construir la URL manualmente.
 *
 * @param {string} token
 * @param {object} distribution - objeto de GET /distributions
 * @returns {{ payload, integrity, distributionId, service, type }}
 */
export async function downloadDistribution(token, distribution) {
  const { id, service, type, links } = distribution;

  // Preferir el link de descarga que viene en la distribución
  const downloadLink = links?.find(l => l.rel === 'download');
  const path = downloadLink
    ? new URL(downloadLink.href).pathname
    : resolveDownloadPath(id, service, type);

  const method = (service === 'fileAct') ? 'POST' : 'GET';
  const body   = (service === 'fileAct' && method === 'POST')
    ? { callback_url: process.env.FILEACT_CALLBACK_URL ?? '' }
    : undefined;

  const { data, integrity } = await swiftFetch(token, path, { method, body });
  return { payload: data, integrity, distributionId: id, service, type };
}

/**
 * Construye el path de descarga si la distribución no trae links.
 */
function resolveDownloadPath(id, service, type) {
  const paths = {
    fin: {
      message:              `/fin/messages/${id}`,
      transmissionReport:   `/fin/transmission-reports/${id}`,
      deliveryReport:       `/fin/delivery-reports/${id}`,
      deliveryNotification: `/fin/delivery-notifications/${id}`,
      archive:              `/fin/archives/${id}`,
      export:               `/fin/exports/${id}`,
    },
    interAct: {
      message:              `/interact/messages/${id}`,
      transmissionReport:   `/interact/transmission-reports/${id}`,
      deliveryReport:       `/interact/delivery-reports/${id}`,
      deliveryNotification: `/interact/delivery-notifications/${id}`,
      archive:              `/interact/archives/${id}`,
      export:               `/interact/exports/${id}`,
    },
    fileAct: {
      message:       `/fileact/messages/${id}`,
      deliveryReport:`/fileact/delivery-reports/${id}`,
      archive:       `/fileact/archives/${id}`,
      export:        `/fileact/exports/${id}`,
    },
  };
  const path = paths[service]?.[type];
  if (!path) throw new Error(`Unknown distribution service/type: ${service}/${type}`);
  return path;
}

/**
 * POST /distributions/{id}/acks
 * Remueve la distribución de la lista pendiente en Alliance Cloud.
 */
export async function ackDistribution(token, distributionId) {
  await swiftFetch(token, `/distributions/${distributionId}/acks`, { method: 'POST', body: {} });
  console.log(`ACK sent for distribution ${distributionId}`);
}

/**
 * POST /distributions/{id}/naks
 * Marca la distribución como fallida — vuelve al siguiente polling.
 */
export async function nakDistribution(token, distributionId, reason = 'Processing error') {
  await swiftFetch(token, `/distributions/${distributionId}/naks`, {
    method: 'POST',
    body:   { message: reason },
  });
  console.log(`NAK sent for distribution ${distributionId}: ${reason}`);
}

/**
 * PATCH /distributions
 * Batch ACK/NAK — hasta 200 distribuciones por llamada.
 *
 * @param {Array<{id, status: 'Ack'|'Nak', message?: string}>} updates
 */
export async function batchUpdateDistributions(token, updates) {
  const { data } = await swiftFetch(token, '/distributions', {
    method: 'PATCH',
    body:   { distributions: updates },
  });
  return data;
}
