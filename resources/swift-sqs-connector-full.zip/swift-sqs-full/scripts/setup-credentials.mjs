/**
 * scripts/setup-credentials.mjs
 * Carga las credenciales Swift en DynamoDB con cifrado KMS.
 * Ejecutar UNA VEZ en el deploy inicial o cuando rotan las credenciales.
 *
 * Uso:
 *   node --env-file=.env.sandbox scripts/setup-credentials.mjs
 *
 * Variables requeridas en .env.sandbox:
 *   SWIFT_ENV=sandbox
 *   SWIFT_CONSUMER_KEY=...
 *   SWIFT_CONSUMER_SECRET=...
 *   DYNAMODB_TABLE_NAME=swift-sqs-sandbox-store
 *   KMS_KEY_ID=arn:aws:kms:...
 *
 * Para prod también necesitas:
 *   SWIFT_PRIVATE_KEY_PEM=-----BEGIN PRIVATE KEY-----\n...
 *   SWIFT_CERTIFICATE_PEM=-----BEGIN CERTIFICATE-----\n...
 */

import { saveCredentials } from '../shared/swift-store.mjs';
import { readFileSync }    from 'fs';

const ENV = process.env.SWIFT_ENV || 'sandbox';

console.log(`\nSetup credentials → DynamoDB (${ENV})\n`);

// En sandbox las llaves RSA las provee Swift dinámicamente —
// guardamos placeholders que el token-refresher sobreescribe en runtime.
// En prod se deben proveer las llaves institucionales reales.
let private_key_pem  = process.env.SWIFT_PRIVATE_KEY_PEM  || 'SANDBOX_PLACEHOLDER';
let certificate_pem  = process.env.SWIFT_CERTIFICATE_PEM  || 'SANDBOX_PLACEHOLDER';

// Si se pasan como archivos PEM
if (process.env.SWIFT_PRIVATE_KEY_FILE) {
  private_key_pem = readFileSync(process.env.SWIFT_PRIVATE_KEY_FILE, 'utf8').trim();
}
if (process.env.SWIFT_CERTIFICATE_FILE) {
  certificate_pem = readFileSync(process.env.SWIFT_CERTIFICATE_FILE, 'utf8').trim();
}

const creds = {
  consumer_key:    process.env.SWIFT_CONSUMER_KEY    ?? (() => { throw new Error('SWIFT_CONSUMER_KEY not set'); })(),
  consumer_secret: process.env.SWIFT_CONSUMER_SECRET ?? (() => { throw new Error('SWIFT_CONSUMER_SECRET not set'); })(),
  private_key_pem,
  certificate_pem,
};

console.log('Consumer key:', creds.consumer_key);
console.log('Environment:', ENV);
console.log('Table:', process.env.DYNAMODB_TABLE_NAME);
console.log('KMS Key:', process.env.KMS_KEY_ID?.substring(0, 30) + '...');
console.log('');

await saveCredentials(creds);

console.log('✓ Credentials saved to DynamoDB with KMS encryption');
console.log('');
console.log('Next step: invoke token-refresher to get the first Bearer token:');
console.log('  aws lambda invoke --function-name swift-sqs-${ENV}-token-refresher /dev/null');
