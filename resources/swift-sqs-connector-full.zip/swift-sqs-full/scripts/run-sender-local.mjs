/**
 * scripts/run-sender-local.mjs
 * Simula un evento SQS para probar el message-sender localmente.
 *
 * Publica mensajes MT103 y pacs.008 de prueba en la cola outbound
 * de LocalStack y verifica que lleguen a send-results.
 *
 * Uso: node --env-file=.env.local scripts/run-sender-local.mjs
 */

import { SQSClient, SendMessageCommand, ReceiveMessageCommand } from '@aws-sdk/client-sqs';
import { handler } from '../lambdas/message-sender/index.mjs';

const sqs = new SQSClient({
  endpoint:    process.env.AWS_ENDPOINT_URL,
  region:      process.env.AWS_REGION,
  credentials: {
    accessKeyId:     process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

// ── Mensajes de prueba ────────────────────────────────────────────────────

const MT103 = `{1:F01BANKPAXXX0000000000}{2:I103BANAPAPAXXXXN}{3:{108:TXN-LOCAL-001}{121:550e8400-e29b-41d4-a716-446655440001}}{4:\r\n:20:TXN-LOCAL-001\r\n:23B:CRED\r\n:32A:250115USD15000,\r\n:50K:/123456789\r\nBANCO ORIGEN PANAMA\r\n:59:/987654321\r\nBENEFICIARIO EJEMPLO\r\n:70:PAGO PRUEBA LOCAL\r\n:71A:SHA\r\n-}{5:{CHK:ABCDEF123456}}`;

const PACS008 = `<?xml version="1.0" encoding="UTF-8"?>
<AppHdr xmlns="urn:iso:std:iso:20022:tech:xsd:head.001.001.02">
  <Fr><FIId><FinInstnId><BICFI>BANKPAXX</BICFI></FinInstnId></FIId></Fr>
  <To><FIId><FinInstnId><BICFI>BANAPAPAXXXX</BICFI></FinInstnId></FIId></To>
  <BizMsgIdr>MSG-LOCAL-001</BizMsgIdr>
  <MsgDefIdr>pacs.008.001.09</MsgDefIdr>
  <CreDt>2025-01-15T10:30:00Z</CreDt>
</AppHdr>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.09">
  <FIToFICstmrCdtTrf>
    <GrpHdr><MsgId>MSG-LOCAL-001</MsgId><CreDtTm>2025-01-15T10:30:00Z</CreDtTm><NbOfTxs>1</NbOfTxs></GrpHdr>
  </FIToFICstmrCdtTrf>
</Document>`;

// ── Simular evento SQS ────────────────────────────────────────────────────

function makeSqsEvent(messages) {
  return {
    Records: messages.map((body, i) => ({
      messageId:     `local-test-${i + 1}`,
      receiptHandle: `receipt-${i + 1}`,
      body,
      attributes:    {},
      messageAttributes: {},
    })),
  };
}

console.log('\n═══ message-sender local test ═══\n');

// Test 1: MT103
console.log('[1/2] Enviando MT103...');
try {
  const result = await handler(makeSqsEvent([MT103]));
  console.log('     MT103 result:', JSON.stringify(result));
} catch (e) {
  console.error('     MT103 error:', e.message);
}

// Test 2: pacs.008
console.log('\n[2/2] Enviando pacs.008...');
try {
  const result = await handler(makeSqsEvent([PACS008]));
  console.log('     pacs.008 result:', JSON.stringify(result));
} catch (e) {
  console.error('     pacs.008 error:', e.message);
}

// Verificar mensajes en send-results
console.log('\n── Mensajes en send-results ──');
try {
  const response = await sqs.send(new ReceiveMessageCommand({
    QueueUrl:            process.env.SQS_SEND_RESULTS_URL,
    MaxNumberOfMessages: 10,
    WaitTimeSeconds:     2,
  }));

  if (response.Messages?.length) {
    response.Messages.forEach((m, i) => {
      const body = JSON.parse(m.Body);
      console.log(`\n[${i + 1}] ${body.format} ${body.message_type}`);
      console.log(`    sender_reference:        ${body.sender_reference}`);
      console.log(`    message_cloud_reference: ${body.message_cloud_reference}`);
      console.log(`    status:                  ${body.status}`);
    });
  } else {
    console.log('    No hay mensajes en send-results (esperado si Swift rechazó)');
  }
} catch (e) {
  console.error('    Error leyendo send-results:', e.message);
}
