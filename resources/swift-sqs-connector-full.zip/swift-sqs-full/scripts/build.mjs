/**
 * scripts/build.mjs
 * Empaqueta cada Lambda + shared/ en un ZIP para CloudFormation.
 *
 * Genera en dist/:
 *   token-refresher.zip
 *   message-poller.zip
 *   message-dispatcher.zip
 *   message-sender.zip
 *
 * Uso: node scripts/build.mjs
 */

import { createWriteStream, mkdirSync } from 'fs';
import { join, dirname }               from 'path';
import { fileURLToPath }               from 'url';
import archiver                        from 'archiver';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT      = join(__dirname, '..');
const DIST      = join(ROOT, 'dist');

mkdirSync(DIST, { recursive: true });

const LAMBDAS = [
  'token-refresher',
  'message-poller',
  'message-dispatcher',
  'message-sender',
];

async function zipLambda(name) {
  return new Promise((resolve, reject) => {
    const output  = createWriteStream(join(DIST, `${name}.zip`));
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => {
      const kb = Math.round(archive.pointer() / 1024);
      console.log(`  ✓ ${name}.zip  (${kb} KB)`);
      resolve();
    });
    archive.on('error', reject);
    archive.pipe(output);

    // Handler de la Lambda
    archive.directory(join(ROOT, 'lambdas', name), false);

    // Módulos compartidos (referenciados como ../../shared/)
    archive.directory(join(ROOT, 'shared'), 'shared');

    // node_modules de producción
    archive.directory(join(ROOT, 'node_modules'), 'node_modules');

    archive.finalize();
  });
}

console.log('\nBuilding Swift SQS Connector Lambdas...\n');

for (const lambda of LAMBDAS) {
  await zipLambda(lambda);
}

console.log(`\n✓ Build complete → dist/\n`);
