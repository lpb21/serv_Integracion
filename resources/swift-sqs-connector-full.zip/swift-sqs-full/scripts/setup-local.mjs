/**
 * scripts/setup-local.mjs
 * Levanta LocalStack y crea todos los recursos AWS locales.
 *
 * Prerequisitos:
 *   - Docker Desktop corriendo con WSL2 integration
 *   - awslocal instalado (pip install awscli-local)
 *   - LocalStack image: localstack/localstack:3.8.0
 *
 * Uso: node scripts/setup-local.mjs
 */

import { execSync } from 'child_process';
import { writeFileSync } from 'fs';

const ENV    = 'sandbox';
const REGION = 'us-east-1';
const ACCT   = '000000000000';  // LocalStack default

function run(cmd, opts = {}) {
  try {
    const out = execSync(cmd, { encoding: 'utf8', stdio: 'pipe', ...opts });
    return out.trim();
  } catch (e) {
    if (opts.ignoreError) return null;
    throw e;
  }
}

console.log('\n═══ Swift SQS Connector — Setup Local (LocalStack) ═══\n');

// 1. Levantar LocalStack si no está corriendo
console.log('[1/4] Verificando LocalStack...');
const running = run('docker ps --filter name=localstack --format "{{.Names}}"', { ignoreError: true });

if (!running?.includes('localstack')) {
  console.log('     Levantando LocalStack...');
  run('docker run --rm -d --name localstack -p 4566:4566 -v /var/run/docker.sock:/var/run/docker.sock localstack/localstack:3.8.0');
  // Esperar que LocalStack esté listo
  let ready = false;
  for (let i = 0; i < 30; i++) {
    await new Promise(r => setTimeout(r, 1000));
    try {
      const health = run('curl -s http://localhost:4566/_localstack/health');
      if (health.includes('"sqs"')) { ready = true; break; }
    } catch {}
  }
  if (!ready) throw new Error('LocalStack no respondió en 30 segundos');
  console.log('     LocalStack listo ✓');
} else {
  console.log('     LocalStack ya está corriendo ✓');
}

// 2. Crear colas SQS
console.log('\n[2/4] Creando colas SQS...');
const queues = [
  'core-swift-mt-inbound',
  'core-swift-mx-inbound',
  'core-swift-outbound',
  'swift-sqs-sandbox-dlq',
  'swift-sqs-sandbox-send-results',
];

for (const q of queues) {
  run(`awslocal sqs create-queue --queue-name ${q} --region ${REGION}`, { ignoreError: true });
  console.log(`     ${q} ✓`);
}

// 3. Crear KMS key (mock en LocalStack)
console.log('\n[3/4] Creando KMS key y tabla DynamoDB...');
const kmsKeyId = run(`awslocal kms create-key --region ${REGION} --query KeyMetadata.KeyId --output text`);
run(`awslocal kms create-alias --alias-name alias/swift-sqs-sandbox-store --target-key-id ${kmsKeyId} --region ${REGION}`, { ignoreError: true });
console.log(`     KMS key: ${kmsKeyId} ✓`);

// Crear tabla DynamoDB
run(`awslocal dynamodb create-table \
  --table-name swift-sqs-sandbox-store \
  --attribute-definitions AttributeName=pk,AttributeType=S \
  --key-schema AttributeName=pk,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region ${REGION}`, { ignoreError: true });
console.log('     DynamoDB table: swift-sqs-sandbox-store ✓');

// 4. Crear secrets iniciales en DynamoDB (placeholder)
const credentialsArn = `arn:aws:secretsmanager:${REGION}:${ACCT}:secret:swift-sqs-sandbox/swift/credentials`;
const tokenArn       = `arn:aws:secretsmanager:${REGION}:${ACCT}:secret:swift-sqs-sandbox/swift/token`;

// Generar .env.local
console.log('\n[4/4] Generando .env.local...');

const envContent = `# Generado por scripts/setup-local.mjs — NO editar manualmente
SWIFT_ENV=sandbox

# LocalStack
AWS_ENDPOINT_URL=http://localhost:4566
AWS_REGION=${REGION}
AWS_ACCESS_KEY_ID=test
AWS_SECRET_ACCESS_KEY=test

# DynamoDB + KMS
DYNAMODB_TABLE_NAME=swift-sqs-sandbox-store
KMS_KEY_ID=${kmsKeyId}

# Colas del core (LocalStack)
SQS_CORE_MT_INBOUND_URL=http://localhost:4566/${ACCT}/core-swift-mt-inbound
SQS_CORE_MX_INBOUND_URL=http://localhost:4566/${ACCT}/core-swift-mx-inbound
SQS_CORE_FILEACT_URL=
SQS_SEND_RESULTS_URL=http://localhost:4566/${ACCT}/swift-sqs-sandbox-send-results
SQS_DLQ_URL=http://localhost:4566/${ACCT}/swift-sqs-sandbox-dlq

# Lambda
DISPATCHER_FUNCTION_NAME=swift-sqs-sandbox-message-dispatcher
MAX_CONCURRENT_DISPATCHERS=5
FILEACT_CALLBACK_URL=
`;

writeFileSync('.env.local', envContent);
console.log('     .env.local ✓');

console.log('\n═══════════════════════════════════════════════════════');
console.log('  Setup completo ✓');
console.log('═══════════════════════════════════════════════════════');
console.log('');
console.log('Siguiente paso — cargar credenciales Swift:');
console.log('');
console.log('  SWIFT_CONSUMER_KEY=<tu_key> \\');
console.log('  SWIFT_CONSUMER_SECRET=<tu_secret> \\');
console.log('  node --env-file=.env.local scripts/setup-credentials.mjs');
console.log('');
console.log('Luego prueba el token:');
console.log('  npm run dev:token');
