/**
 * scripts/run-dispatcher-local.mjs
 * Simula una invocación async del message-dispatcher localmente.
 * Útil para probar la descarga y el enrutamiento a SQS sin el poller.
 *
 * Requiere que el token-refresher haya corrido primero:
 *   npm run dev:token
 *
 * Uso: node --env-file=.env.local scripts/run-dispatcher-local.mjs
 */

import { SQSClient, ReceiveMessageCommand } from '@aws-sdk/client-sqs';
import { getToken }                          from '../shared/swift-store.mjs';
import { listDistributions }                 from '../shared/swift-client.mjs';
import { handler }                           from '../lambdas/message-dispatcher/index.mjs';

const sqs = new SQSClient({
  endpoint:    process.env.AWS_ENDPOINT_URL,
  region:      process.env.AWS_REGION,
  credentials: {
    accessKeyId:     process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

console.log('\n═══ message-dispatcher local test ═══\n');

// 1. Obtener token
const { access_token: token } = await getToken();
console.log('[1/3] Token obtenido ✓\n');

// 2. Listar distribuciones disponibles en el sandbox
const distributions = await listDistributions(token);
console.log(`[2/3] Distribuciones disponibles: ${distributions.length}`);

if (distributions.length === 0) {
  console.log('      No hay distribuciones. Usa el sandbox de Swift para inyectar mensajes.');
  process.exit(0);
}

// Mostrar primeras 5
distributions.slice(0, 5).forEach((d, i) => {
  console.log(`      [${i + 1}] id=${d.id} service=${d.service} type=${d.type}`);
});

// 3. Procesar la primera distribución
const first = distributions[0];
console.log(`\n[3/3] Procesando distribución ${first.id} (${first.service}/${first.type})...`);

try {
  await handler({
    distributionId:        first.id,
    service:               first.service,
    type:                  first.type,
    links:                 first.links ?? [],
    messageCloudReference: first.message_cloud_reference,
  });
  console.log('      Dispatcher completado ✓');
} catch (e) {
  console.error('      Dispatcher error:', e.message);
}

// 4. Ver qué llegó a las colas del core
console.log('\n── Mensajes en colas del core ──');

for (const [name, url] of [
  ['MT inbound', process.env.SQS_CORE_MT_INBOUND_URL],
  ['MX inbound', process.env.SQS_CORE_MX_INBOUND_URL],
]) {
  if (!url) continue;
  const response = await sqs.send(new ReceiveMessageCommand({
    QueueUrl:            url,
    MaxNumberOfMessages: 5,
    WaitTimeSeconds:     1,
    MessageAttributeNames: ['All'],
  })).catch(() => ({ Messages: [] }));

  if (response.Messages?.length) {
    console.log(`\n${name} (${response.Messages.length} mensaje(s)):`);
    response.Messages.forEach(m => {
      const svc  = m.MessageAttributes?.service?.StringValue;
      const type = m.MessageAttributes?.distributionType?.StringValue;
      console.log(`  service=${svc} type=${type} body[0..80]=${m.Body.substring(0, 80)}...`);
    });
  }
}
