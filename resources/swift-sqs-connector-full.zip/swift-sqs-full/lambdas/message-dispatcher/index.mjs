/**
 * Lambda: message-dispatcher
 * Invocado async por message-poller (InvocationType=Event)
 *
 * Responsabilidades:
 *   1. Lee Bearer token de DynamoDB
 *   2. Descarga el payload de la distribución usando el link rel:download
 *   3. Decodifica base64 → texto plano (MT o XML MX)
 *   4. Publica en la cola SQS del core correspondiente
 *   5. Envía ACK a Swift — remueve la distribución de la lista pendiente
 *
 * Enrutamiento:
 *   fin      → SQS_CORE_MT_INBOUND_URL
 *   interAct → SQS_CORE_MX_INBOUND_URL
 *   fileAct  → SQS_CORE_FILEACT_URL (vacío = error descriptivo)
 *
 * Environment variables:
 *   SWIFT_ENV               sandbox | test | prod
 *   DYNAMODB_TABLE_NAME     Tabla DynamoDB del store
 *   KMS_KEY_ID              ID de la clave KMS
 *   SQS_CORE_MT_INBOUND_URL Cola MT del core
 *   SQS_CORE_MX_INBOUND_URL Cola MX del core
 *   SQS_CORE_FILEACT_URL    Cola FileAct del core (opcional)
 *   SQS_DLQ_URL             DLQ del conector
 *   FILEACT_CALLBACK_URL    Callback URL para FileAct async (opcional)
 */

import { SQSClient, SendMessageCommand } from '@aws-sdk/client-sqs';
import { getToken }                       from '../../shared/swift-store.mjs';
import { downloadDistribution, ackDistribution, nakDistribution } from '../../shared/swift-client.mjs';
import { resolveQueueUrl, buildSqsMessage } from '../../shared/queue-router.mjs';

const sqs = new SQSClient({});

export const handler = async (event) => {
  const { distributionId, service, type, links } = event;

  console.log('message-dispatcher: processing', { distributionId, service, type });

  // 1. Leer token de DynamoDB
  const { access_token: token } = await getToken();

  let downloaded;

  try {
    // 2. Descargar distribución de Swift
    downloaded = await downloadDistribution(token, {
      id: distributionId,
      service,
      type,
      links,
    });

    // 3. Resolver cola del core y construir mensaje SQS
    const queueUrl = resolveQueueUrl(service);
    const { messageBody, messageAttributes } = buildSqsMessage(downloaded);

    // 4. Publicar en cola del core (texto plano)
    const result = await sqs.send(new SendMessageCommand({
      QueueUrl:          queueUrl,
      MessageBody:       messageBody,
      MessageAttributes: messageAttributes,
    }));

    console.log('message-dispatcher: published to SQS', {
      distributionId,
      service,
      type,
      messageId: result.MessageId,
    });

    // 5. ACK a Swift — remueve la distribución de la lista
    await ackDistribution(token, distributionId);

    return { statusCode: 200, distributionId };

  } catch (err) {
    console.error('message-dispatcher: error', {
      distributionId,
      service,
      type,
      error:      err.message,
      swiftCode:  err.swiftCode,
      statusCode: err.statusCode,
    });

    // NAK solo en errores 4xx (fatales de negocio) — no en errores de red
    if (err.statusCode && err.statusCode >= 400 && err.statusCode < 500) {
      try {
        await nakDistribution(token, distributionId, err.message.slice(0, 200));
      } catch (nakErr) {
        console.error('message-dispatcher: failed to NAK', nakErr.message);
      }
    }

    // Re-throw para que el async retry config del Lambda aplique
    throw err;
  }
};
