/**
 * Lambda: message-poller
 * Trigger: EventBridge Scheduler — rate(2 minutes)
 *
 * Responsabilidades:
 *   1. Lee Bearer token de DynamoDB (descifrado con KMS via swift-store.mjs)
 *   2. GET /distributions — paginado con rel:next
 *   3. Invoca message-dispatcher async (InvocationType=Event) por cada distribución
 *
 * El poller NO descarga payloads — solo descubre IDs y delega al dispatcher.
 * Esto lo mantiene rápido e idempotente.
 *
 * Environment variables:
 *   SWIFT_ENV                   sandbox | test | prod
 *   DYNAMODB_TABLE_NAME         Tabla DynamoDB del store
 *   KMS_KEY_ID                  ID de la clave KMS
 *   DISPATCHER_FUNCTION_NAME    Nombre o ARN del message-dispatcher
 *   MAX_CONCURRENT_DISPATCHERS  Máximo de dispatchers en paralelo (default 25)
 */

import { LambdaClient, InvokeCommand } from '@aws-sdk/client-lambda';
import { getToken }                     from '../../shared/swift-store.mjs';
import { listDistributions }            from '../../shared/swift-client.mjs';

const lambda = new LambdaClient({});
const MAX_CONCURRENT = parseInt(process.env.MAX_CONCURRENT_DISPATCHERS || '25', 10);

/**
 * Invoca el dispatcher de forma asíncrona (fire-and-forget).
 */
async function invokeDispatcher(distribution) {
  const payload = JSON.stringify({
    distributionId:        distribution.id,
    service:               distribution.service,
    type:                  distribution.type,
    copy:                  distribution.copy ?? false,
    messageCloudReference: distribution.message_cloud_reference ?? null,
    links:                 distribution.links ?? [],
  });

  await lambda.send(new InvokeCommand({
    FunctionName:   process.env.DISPATCHER_FUNCTION_NAME,
    InvocationType: 'Event',
    Payload:        Buffer.from(payload),
  }));
}

/**
 * Despacha distribuciones en batches respetando MAX_CONCURRENT.
 */
async function dispatchAll(distributions) {
  let dispatched = 0;
  let failed     = 0;

  for (let i = 0; i < distributions.length; i += MAX_CONCURRENT) {
    const batch   = distributions.slice(i, i + MAX_CONCURRENT);
    const results = await Promise.allSettled(batch.map(d => invokeDispatcher(d)));

    for (const result of results) {
      if (result.status === 'fulfilled') dispatched++;
      else {
        failed++;
        console.error('Failed to invoke dispatcher:', result.reason?.message);
      }
    }
  }

  return { dispatched, failed };
}

export const handler = async () => {
  console.log('message-poller: starting');

  // 1. Leer token de DynamoDB (con caché en memoria)
  const { access_token: token } = await getToken();

  // 2. GET /distributions — paginado
  const distributions = await listDistributions(token);
  console.log(`message-poller: found ${distributions.length} distribution(s)`);

  if (distributions.length === 0) {
    return { statusCode: 200, message: 'No distributions available' };
  }

  // Log por tipo
  const summary = distributions.reduce((acc, d) => {
    const key = `${d.service}/${d.type}`;
    acc[key]  = (acc[key] ?? 0) + 1;
    return acc;
  }, {});
  console.log('message-poller: breakdown', summary);

  // 3. Invocar dispatcher async por cada distribución
  const { dispatched, failed } = await dispatchAll(distributions);
  console.log(`message-poller: dispatched=${dispatched} failed=${failed}`);

  return { statusCode: 200, dispatched, failed };
};
