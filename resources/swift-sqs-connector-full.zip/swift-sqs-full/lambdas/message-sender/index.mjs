/**
 * Lambda: message-sender
 * Trigger: SQS — cola outbound del core bancario
 *
 * El core publica mensajes MT o MX como TEXTO PLANO en el body SQS
 * — sin JSON wrapper, sin metadata adicional.
 *
 * Responsabilidades:
 *   1. Lee token y credenciales PKI de DynamoDB
 *   2. Auto-detecta formato MT vs MX por el contenido del body
 *   3. Parsea el mensaje y extrae los campos del spec de Swift
 *   4. Construye X-SWIFT-Signature (JWS RS256 con digest SHA256)
 *   5. POST a Swift (/fin/messages o /interact/messages)
 *   6. Publica resultado en SQS send-results para que el core correlacione
 *
 * Errores fatales (no reintentar):
 *   - Error de parseo MT/MX
 *   - 4xx de Swift (mensaje inválido, BIC inexistente)
 *
 * Errores transientes (reintentar):
 *   - 5xx de Swift
 *   - Error de red
 *
 * Environment variables:
 *   SWIFT_ENV             sandbox | test | prod
 *   DYNAMODB_TABLE_NAME   Tabla DynamoDB del store
 *   KMS_KEY_ID            ID de la clave KMS
 *   SQS_SEND_RESULTS_URL  Cola de resultados hacia el core
 */

import { SQSClient, SendMessageCommand } from '@aws-sdk/client-sqs';
import { getToken, getCredentials }       from '../../shared/swift-store.mjs';
import { sendMessages, detectService }    from '../../shared/swift-client-outbound.mjs';
import { parseMTMessage }                 from '../../shared/mt-parser.mjs';
import { parseMXMessage, detectMessageFormat } from '../../shared/mx-parser.mjs';

const sqs = new SQSClient({});

/**
 * Transforma el body SQS (texto plano MT o MX) al formato del spec de Swift.
 */
function transformMessage(rawBody) {
  if (!rawBody?.trim()) throw new Error('SQS body is empty');

  const format = detectMessageFormat(rawBody);
  let swiftMessage;

  if (format === 'MT') {
    swiftMessage = parseMTMessage(rawBody);
  } else if (format === 'MX') {
    swiftMessage = parseMXMessage(rawBody);
  } else {
    throw new Error('Cannot determine message format from body content');
  }

  const { _meta, ...cleanMessage } = swiftMessage;
  return {
    swiftMessage: cleanMessage,
    format,
    service: detectService(swiftMessage.message_type),
    _meta,
  };
}

async function publishResult(sqsMessageId, swiftMessage, swiftResponse, service, format) {
  await sqs.send(new SendMessageCommand({
    QueueUrl: process.env.SQS_SEND_RESULTS_URL,
    MessageBody: JSON.stringify({
      sender_reference:        swiftMessage.sender_reference,
      message_cloud_reference: swiftResponse.message_cloud_reference ?? null,
      message_type:            swiftMessage.message_type,
      service,
      format,
      status:      'Accepted',
      sentAt:      new Date().toISOString(),
      sqsMessageId,
      swiftEnv:    process.env.SWIFT_ENV ?? 'sandbox',
    }),
    MessageAttributes: {
      status:          { DataType: 'String', StringValue: 'Accepted' },
      service:         { DataType: 'String', StringValue: service },
      format:          { DataType: 'String', StringValue: format },
      senderReference: { DataType: 'String', StringValue: swiftMessage.sender_reference },
      messageType:     { DataType: 'String', StringValue: swiftMessage.message_type },
    },
  }));
}

async function publishError(sqsMessageId, error, swiftMessage = null) {
  await sqs.send(new SendMessageCommand({
    QueueUrl: process.env.SQS_SEND_RESULTS_URL,
    MessageBody: JSON.stringify({
      sender_reference: swiftMessage?.sender_reference ?? 'unknown',
      message_type:     swiftMessage?.message_type     ?? 'unknown',
      status:           'Failed',
      error_code:       error.swiftCode ?? 'PARSE_ERROR',
      error_text:       error.message.slice(0, 500),
      failedAt:         new Date().toISOString(),
      sqsMessageId,
      swiftEnv:         process.env.SWIFT_ENV ?? 'sandbox',
    }),
    MessageAttributes: {
      status:    { DataType: 'String', StringValue: 'Failed' },
      errorCode: { DataType: 'String', StringValue: error.swiftCode ?? 'PARSE_ERROR' },
    },
  })).catch(e => console.error('Failed to publish error result:', e.message));
}

export const handler = async (event) => {
  const batchItemFailures = [];

  // Cargar token y credenciales PKI en paralelo (con caché en memoria)
  const [{ access_token: token }, creds] = await Promise.all([
    getToken(),
    getCredentials(),
  ]);

  // Credenciales PKI para X-SWIFT-Signature
  const credentials = {
    privateKeyPem:  creds.private_key_pem,
    certificatePem: creds.certificate_pem,
  };

  for (const record of event.Records) {
    let transformed;

    try {
      const rawBody = record.body;

      // 1. Detectar formato y parsear MT/MX → formato del spec
      transformed = transformMessage(rawBody);
      const { swiftMessage, format, service, _meta } = transformed;

      console.log('message-sender: parsed', {
        format,
        service,
        message_type:     swiftMessage.message_type,
        sender_reference: swiftMessage.sender_reference,
        receiver:         swiftMessage.receiver,
        uetr:             _meta?.uetr ?? null,
        sqsMessageId:     record.messageId,
      });

      // 2. Enviar a Swift con X-SWIFT-Signature
      const swiftResponse = await sendMessages(token, swiftMessage, credentials);

      console.log('message-sender: sent', {
        sender_reference:        swiftMessage.sender_reference,
        message_cloud_reference: swiftResponse.message_cloud_reference,
      });

      // 3. Notificar resultado al core
      await publishResult(record.messageId, swiftMessage, swiftResponse, service, format);

    } catch (err) {
      console.error('message-sender: error', {
        sqsMessageId: record.messageId,
        error:        err.message,
        swiftCode:    err.swiftCode,
        statusCode:   err.statusCode,
      });

      await publishError(record.messageId, err, transformed?.swiftMessage);

      // Errores fatales → descartar, no reintentar
      const isFatal = (err.statusCode >= 400 && err.statusCode < 500)
        || err.message.includes('not found')
        || err.message.includes('required')
        || err.message.includes('exceeds')
        || err.message.includes('Cannot detect')
        || err.message.includes('missing')
        || err.message.includes('empty');

      if (!isFatal) {
        batchItemFailures.push({ itemIdentifier: record.messageId });
      }
    }
  }

  return { batchItemFailures };
};
