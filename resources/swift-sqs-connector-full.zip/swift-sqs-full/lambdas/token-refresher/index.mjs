/**
 * Lambda: token-refresher
 * Trigger: EventBridge Scheduler every 50 minutes
 *
 * Obtiene el Bearer token de Swift OAuth2 y lo guarda
 * cifrado en DynamoDB con KMS via swift-store.mjs.
 *
 * Environment variables:
 *   SWIFT_ENV            sandbox | test | prod
 *   DYNAMODB_TABLE_NAME  Nombre de la tabla DynamoDB
 *   KMS_KEY_ID           ID o ARN de la clave KMS
 */

import crypto from 'crypto';
import { getCredentials, saveToken } from '../../shared/swift-store.mjs';

const CONFIG = {
  sandbox: { baseUrl: 'https://sandbox.swift.com',                tokenUri: '/oauth2/v1/token', scope: 'swift.alliancecloud.api' },
  test:    { baseUrl: 'https://api-test.swiftnet.sipn.swift.com', tokenUri: '/oauth2/v1/token', scope: 'swift.alliancecloud.api' },
  prod:    { baseUrl: 'https://api.swiftnet.sipn.swift.com',      tokenUri: '/oauth2/v1/token', scope: 'swift.alliancecloud.api' },
};

const ENV = process.env.SWIFT_ENV || 'sandbox';
const { baseUrl, tokenUri, scope } = CONFIG[ENV];

function base64UrlEncode(str) {
  return str.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

function getX5c(certificatePem) {
  return certificatePem
    .replace('-----BEGIN CERTIFICATE-----', '')
    .replace('-----END CERTIFICATE-----', '')
    .replace(/\n/g, '');
}

function getSubjectDn(certificatePem) {
  try {
    const cert = new crypto.X509Certificate(certificatePem);
    return cert.subject.split('\n').filter(Boolean).join(', ');
  } catch {
    return 'CN=demo-swift-sandbox-consumer, O=Demo, L=London, S=London, C=GB';
  }
}

function buildJwt({ privateKeyPem, certificatePem, consumerKey }) {
  const x5c     = getX5c(certificatePem);
  const subject = getSubjectDn(certificatePem);
  const now     = Math.floor(Date.now() / 1000);

  const header  = { alg: 'RS256', typ: 'JWT', x5c: [x5c] };
  const payload = {
    iss: consumerKey,
    sub: subject,
    aud: `${baseUrl}${tokenUri}`.replace('https://', ''),
    exp: now + 15,
    iat: now, nbf: now,
    jti: Math.random().toString(36).substring(2, 15) +
         Math.random().toString(36).substring(2, 15),
  };

  const h  = base64UrlEncode(Buffer.from(JSON.stringify(header)).toString('base64'));
  const p  = base64UrlEncode(Buffer.from(JSON.stringify(payload)).toString('base64'));
  const pk = crypto.createPrivateKey({ key: privateKeyPem });
  const s  = crypto.createSign('RSA-SHA256').update(`${h}.${p}`).sign(pk);
  return `${h}.${p}.${base64UrlEncode(s.toString('base64'))}`;
}

async function fetchSwiftToken(creds) {
  let { consumer_key, consumer_secret, private_key_pem, certificate_pem } = creds;

  // En sandbox Swift provee sus propias llaves de prueba
  if (ENV === 'sandbox') {
    const SERVER = 'https://sandbox.swift.com';
    const [pkRes, certRes] = await Promise.all([
      fetch(`${SERVER}/sandbox-selfsigned-dummy-secret/privatekey2`),
      fetch(`${SERVER}/sandbox-selfsigned-dummy-secret/certificate2`),
    ]);
    private_key_pem = `-----BEGIN PRIVATE KEY-----\n${(await pkRes.text()).trim()}\n-----END PRIVATE KEY-----`;
    certificate_pem = `-----BEGIN CERTIFICATE-----\n${(await certRes.text()).trim()}\n-----END CERTIFICATE-----`;
  }

  const assertion = buildJwt({ privateKeyPem: private_key_pem, certificatePem: certificate_pem, consumerKey: consumer_key });
  const basicAuth = Buffer.from(`${consumer_key}:${consumer_secret}`).toString('base64');

  const response = await fetch(`${baseUrl}${tokenUri}`, {
    method: 'POST',
    headers: {
      'Content-Type':  'application/x-www-form-urlencoded',
      'Accept':        'application/json',
      'Authorization': `Basic ${basicAuth}`,
    },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion,
      scope,
    }).toString(),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(`Swift OAuth failed ${response.status}: ${JSON.stringify(err)}`);
  }

  return response.json();
}

export const handler = async () => {
  console.log('token-refresher: starting', { env: ENV });

  // 1. Leer credenciales desde DynamoDB (descifradas con KMS)
  const credentials = await getCredentials();

  // 2. Obtener Bearer token de Swift
  const tokenData = await fetchSwiftToken(credentials);
  console.log('token-refresher: token obtained, expires_in=', tokenData.expires_in);

  // 3. Guardar token cifrado en DynamoDB con KMS
  await saveToken(tokenData);

  console.log('token-refresher: completed successfully');
  return { statusCode: 200, message: 'Token refreshed and saved to DynamoDB' };
};
