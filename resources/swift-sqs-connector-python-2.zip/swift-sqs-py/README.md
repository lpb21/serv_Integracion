# Swift SQS Connector (Python)

Conector serverless AWS entre la **Swift Messaging API v2.1.0** (Alliance Cloud)
y un core bancario via SQS. Python 3.12 + boto3 + cryptography.

## Arquitectura

- **token-refresher** — EventBridge cada 50 min. OAuth2 JWT-Bearer contra Swift, guarda el token cifrado (KMS) en DynamoDB.
- **message-poller** — EventBridge cada 2 min. `GET /distributions` paginado, invoca dispatcher async.
- **message-dispatcher** — descarga por link `rel:download`, decodifica base64 → texto plano, publica en la cola del core, ACK a Swift.
- **message-sender** — trigger SQS outbound del core. Auto-detecta MT/MX, parsea, envía con `X-SWIFT-Signature`, notifica en send-results.

Almacenamiento de secretos: **DynamoDB + KMS** (tabla única, campos cifrados).

## Estructura

```
swift-sqs-py/
├── lambdas/
│   ├── token_refresher/handler.py
│   ├── message_poller/handler.py
│   ├── message_dispatcher/handler.py
│   └── message_sender/handler.py
├── shared/
│   ├── swift_store.py            # DynamoDB + KMS
│   ├── swift_auth.py             # JWT RS256 + token OAuth2
│   ├── swift_client.py           # inbound (distributions, download, ACK)
│   ├── swift_client_outbound.py  # outbound (POST messages)
│   ├── swift_signature.py        # X-SWIFT-Signature
│   ├── mt_parser.py              # parser MT (5 bloques)
│   ├── mx_parser.py              # parser MX (AppHdr + Document)
│   └── queue_router.py           # enrutamiento service → SQS
├── cloudformation/               # 7 stacks + deploy-all.sh
├── scripts/
│   ├── setup_local.py            # LocalStack + recursos
│   ├── setup_credentials.py      # carga credenciales en DynamoDB
│   ├── build.py                  # empaqueta ZIPs
│   ├── run_sender_local.py       # test sender MT103/pacs.008
│   └── run_dispatcher_local.py   # test dispatcher vs sandbox
└── tests/
    ├── unit/test_parsers.py      # parsers sin dependencias
    └── sandbox/integration.py    # integracion sandbox real
```

## Setup local (WSL2 + LocalStack)

```bash
# 1. Dependencias
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 2. LocalStack + recursos AWS locales
python scripts/setup_local.py

# 3. Cargar credenciales Swift
export $(grep -v "^#" .env.local | xargs)
export SWIFT_CONSUMER_KEY=<tu_key>
export SWIFT_CONSUMER_SECRET=<tu_secret>
python scripts/setup_credentials.py

# 4. Primer token
python -m lambdas.token_refresher.handler

# 5. Tests
python tests/unit/test_parsers.py
python scripts/run_sender_local.py
python scripts/run_dispatcher_local.py
```

## Deploy AWS

```bash
# 1. Build de los ZIPs
python scripts/build.py

# 2. Deploy de los 7 stacks en orden
cd cloudformation
chmod +x deploy-all.sh
./deploy-all.sh sandbox us-east-1 \
  core-swift-mt-inbound core-swift-mx-inbound core-swift-outbound \
  mi-bucket-deploy

# 3. Cargar credenciales en DynamoDB (usar outputs del deploy)
DYNAMODB_TABLE_NAME=... KMS_KEY_ID=... python scripts/setup_credentials.py

# 4. Primer token
aws lambda invoke --function-name swift-sqs-sandbox-token-refresher /dev/null
```

## Referencias

- Swift Messaging API: https://developer.swift.com/apis/swift-messaging-api
- Autenticación JWT-Bearer: https://docs.developer.swift.com/docs/api-guides/swift-messaging-api/authentication
- Sample code oficial: https://github.com/swiftinc/api-sample-code
